package org.capg.dao;

import java.util.List;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.LoginBean;
import org.capg.model.Transaction;

public interface ILoginDao {
	public Customer isValidLogin(LoginBean loginBean);
	
	public boolean createCustomer(Customer customer);

	public Account createAccount(Account account);

	public List<Account> getAllFromAccounts(Integer custId);

	public Account getAccount(long accountNo);

	public boolean createTransaction(Transaction transaction);

	public List<Account> getAllToAccounts(Integer custId);

	public List<Transaction> getAllTransactions(int custId);
}
