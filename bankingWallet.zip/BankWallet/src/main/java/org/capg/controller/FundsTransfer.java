package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Account;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;

@WebServlet("/FundsTransfer")
public class FundsTransfer extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
		
		ILoginService loginService=new LoginServiceImpl(); 
		List<Account> accounts=loginService.getAllFromAccounts((Integer)session.getAttribute("custId"));
		List<Account> accounts2=loginService.getAllToAccounts((Integer)session.getAttribute("custId"));
		
			
		out.println("<!DOCTYPE html>\r\n" + 
				"<html>\r\n" + 
				"<head>\r\n" + 
				"<meta charset=\"ISO-8859-1\">\r\n" + 
				"<link type=\"text/css\" rel=\"stylesheet\" href=\"../styles/createAccount.css\">\r\n" + 
				"<title>capgBanking</title>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"<form method=\"post\" action=\"CreateFunds\">\r\n" + 
				"	<div class=\"account\" style = \"position:fixed; left:30%; top:20px; background-color:#66b3ff;\">\r\n" + 
				"		<table cellspacing=\"20px\">\r\n" + 
				"			<tr>\r\n" + 
				"				<th colspan=\"3\">Fund Transfer</th>\r\n" + 
				"			</tr>\r\n" + 
				"			<tr>\r\n" + 
				"				<td>From Account:</td>\r\n" + 
				"				<td>		\r\n" + 
				"					<select name=\"FromaccountNo\">\r\n"); 
				for(Account account:accounts)
				out.println("<option value="+ account.getAccountNumber()+">"+account.getAccountNumber() +"-"+account.getAccountType()+"</option>\r\n" ); 
				
				out.println("</select>\r\n" + 
				"					\r\n" + 
				"\r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"			\r\n" + 
				"			<tr>\r\n" + 
				"				<td>To Account:</td>\r\n" + 
				"				<td>		\r\n" + 
				"					<select name=\"ToaccountNo\">\r\n"); 
				for(Account account:accounts2)
				out.println("<option value="+ account.getAccountNumber()+">"+account.getAccountNumber() +"-"+account.getAccountType()+"</option>\r\n" ); 
				
				out.println("</select>\r\n" + 
				"					\r\n" + 
				"\r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"			\r\n" + 
				"			<tr>\r\n" + 
				"				<td></td>\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"radio\" name=\"type\" value=\"credit\">Deposit	\r\n" + 
				"					<input type=\"radio\" name=\"type\" value=\"debit\">Withdraw	\r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"			<tr>\r\n" + 
				"				<td>Amount:</td>\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"number\"  name=\"amount\" >\r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"			<tr>\r\n" + 
				"				<td>Description:</td>\r\n" + 
				"				<td>\r\n" + 
				"					<input type=\"text\"  name=\"description\" >\r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"			<tr>\r\n" + 
				"				<td></td>\r\n" + 
				"				<td>\r\n" + 
				"					<button type=\"submit\" value=\"tranasction\" name=\"transaction\" class=\"btn\" ><b>Do Transaction</b></button>\r\n" + 
				"					\r\n" + 
				"				</td>\r\n" + 
				"			</tr>\r\n" + 
				"		\r\n" + 
				"		</table>\r\n" + 
				"	\r\n" + 
				"	</div>\r\n" + 
				"\r\n" + 
				"</form>\r\n" + 
				"</body>\r\n" + 
				"</html>");
	}

}
