package org.capg.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Transaction;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;


@WebServlet("/CreateTransaction")
public class CreateTransaction extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		ILoginService service=new LoginServiceImpl();
		
		 Account account=new Account();
		 
		 String accountNo=request.getParameter("accountNo");
		 String description=request.getParameter("description");
		 String amount=request.getParameter("amount");
		 String transactionType=request.getParameter("type");
		 
		 Transaction transaction=new Transaction();
		
		 transaction.setTransactionDate(LocalDate.now());
		 transaction.setAmount(Double.parseDouble(amount));
		 transaction.setTransactionType(transactionType);
		 transaction.setDescription(description);
		
		 account.setAccountNumber(Long.parseLong(accountNo));
		 transaction.setToAccount(0);
		 transaction.setFromAccount(Long.parseLong(accountNo));
		 
		   HttpSession session=request.getSession();
		   int custId=Integer.parseInt(session.getAttribute("custId").toString());
		   
		   Customer customer=new Customer();
		   
		   customer.setCustomerId(custId);
		   transaction.setCustomerId(custId);
		 
		 Account acc=service.getAccount(Long.parseLong(accountNo));
		
		 if(transaction.getTransactionType().equals("debit")) { 
		   if(transaction.getAmount()<=acc.getOpeningBalance())
		      {
			  
			   if(service.createTransaction(transaction))
			   {
				   response.sendRedirect("DepWitd");
				   System.out.println("Debit Transaction Done!");
			   }
		      }
		    else {
			   response.sendRedirect("DepWitd");
			   System.out.println("Amount less then required");
		         }
		}
		  else if(service.createTransaction(transaction))
			  {
			   response.sendRedirect("DepWitd");
			   System.out.println("Credit Transaction Done!");
		      }
			   
			   
		  else
		  {
			  response.sendRedirect("DepWitd");
			  System.out.println("failed!");
	
		  }
	
	}

}
